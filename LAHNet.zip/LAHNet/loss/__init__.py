from .make_loss import Make_Criterion

__ALL__ = ['Make_Criterion']