from .LAHNet import LAHNet

__ALL__ = ['LAHNet']

# It is easy to add other models and make calls to them.
